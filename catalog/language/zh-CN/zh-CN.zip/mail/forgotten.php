<?php
// Text
$_['text_subject']  = '%s-新密码';
$_['text_greeting'] = '从 %s 请求一个新的密码。';
$_['text_password'] = '您的新密码是：';
