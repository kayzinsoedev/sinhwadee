<?php
// Text
$_['text_subject']	= '%s-商品點评';
$_['text_waiting']	= '有一个新的商品點评正在等待处理。';
$_['text_product']	= '商品： %s';
$_['text_reviewer']	= '點评者： %s';
$_['text_rating']	= '评分： %s';
$_['text_review']	= '點评文章：';