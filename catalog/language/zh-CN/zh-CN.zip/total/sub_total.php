<?php
$_['text_sub_total'] = '小计';