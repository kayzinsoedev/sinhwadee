<?php
$_['text_credit']   = '商店信用';
$_['text_order_id'] = '订单 ID： # %s';