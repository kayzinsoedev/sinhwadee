<?php
// Text
$_['text_voucher'] = '礼品劵 (%s)';