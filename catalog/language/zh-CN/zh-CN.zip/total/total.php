<?php
$_['text_total'] = '合计';