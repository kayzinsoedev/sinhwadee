<?php
// Text
$_['text_coupon'] = '优惠券 (%s)';