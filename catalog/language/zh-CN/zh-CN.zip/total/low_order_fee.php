<?php
$_['text_low_order_fee'] = '小额订单收费';