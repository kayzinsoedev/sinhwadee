<?php
// Text
$_['text_upload']    = '已成功上载您的文件 ！';

// Error
$_['error_filename'] = '文件名必须介于 3 和 64 个字符之间 ！';
$_['error_filetype'] = '文件类型无效 ！';
$_['error_upload']   = '要求上传 ！';
