<?php
// Text
$_['text_captcha'] = '验证码';

// Entry
$_['entry_captcha'] = '请完成下面的验证码验证';

// Error
$_['error_captcha'] = '验证码不正确';
