<?php
// Heading
$_['heading_ncat']     = '分类';
$_['heading_title']    = '分类';
$_['head_search']      = 'Article Search';
$_['artkey']           = 'Keyword';
$_['button_headlines'] = 'Blog';
