<?php
$_ = array(
    'heading_title' =>  '价格',
);