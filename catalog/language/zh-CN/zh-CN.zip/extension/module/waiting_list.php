<?php
    $_ = array(
        'entry_email'               =>  '电子邮件',
        'button_submit'             =>  '提交',
        // More towards General Usage
        'error_title'               =>  'Opss..',
        'error_general'             =>  '提交失败，请刷新或稍后再试',
        'success_title'             => '成功提交',
    );