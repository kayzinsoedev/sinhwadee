<?php
// Text
$_['text_total_shipping']		= '货运';
$_['text_total_discount']		= '折扣';
$_['text_total_tax']			= '税收';
$_['text_total_sub']			= '小计';
$_['text_total']				= '总计';