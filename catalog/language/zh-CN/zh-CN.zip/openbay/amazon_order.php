<?php
// Text
$_['text_paid_amazon'] 			= '在亚马逊网站上支付';
$_['text_total_shipping'] 		= '货运';
$_['text_total_shipping_tax'] 	= '货运税';
$_['text_total_giftwrap'] 		= '礼品包装';
$_['text_total_giftwrap_tax'] 	= '礼品包装税';
$_['text_total_sub'] 			= '小计';
$_['text_tax'] 					= '税收';
$_['text_total'] 				= '总计';