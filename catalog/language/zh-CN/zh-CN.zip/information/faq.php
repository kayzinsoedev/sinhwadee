<?php
// Heading
$_['heading_title']  = '常见问题';

// Text
$_['text_no_faq_found'] = '抱歉，找不到常见问题解答！';
