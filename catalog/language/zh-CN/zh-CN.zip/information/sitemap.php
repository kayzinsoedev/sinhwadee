<?php
// Heading
$_['heading_title']    = '网站地图';

// Text
$_['text_special']     = '特别优惠';
$_['text_account']     = '我的账户';
$_['text_edit']        = '帐户信息';
$_['text_password']    = '密码';
$_['text_address']     = '收货地址';
$_['text_history']     = '订单记录';
$_['text_download']    = '下载附件';
$_['text_cart']        = '购物车';
$_['text_checkout']    = '结帐';
$_['text_search']      = '搜索';
$_['text_information'] = '信息';
$_['text_contact']     = '联系我们';