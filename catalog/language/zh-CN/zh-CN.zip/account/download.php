<?php
// Heading
$_['heading_title']     = '帐户下载';

// Text
$_['text_account']      = '帐户';
$_['text_downloads']    = '下载附件';
$_['text_empty']        = '您没有任何可下载的商品订单 ！';

// Column
$_['column_order_id']   = '订单 ID';
$_['column_name']       = '名称';
$_['column_size']       = '大小';
$_['column_date_added'] = '加入日期';