<?php
// Heading
$_['heading_title']      = '您的奖赏积分';

// Column
$_['column_date_added']  = '加入日期';
$_['column_description'] = '描述';
$_['column_points']      = '积分';

// Text
$_['text_account']       = '帐户';
$_['text_reward']        = '奖赏积分';
$_['text_total']         = '您的奖赏积分总数是：';
$_['text_empty']         = '您没有任何奖赏积分 ！';