<?php
// Heading
$_['heading_title'] = '帐户退出';

// Text
$_['text_message']  = '<p>您已退出您的帐户。现在您可以安全离开电脑。</p><p>您的购物车已被保存，当您再次登录到您的帐户时，里面的项目将被还原。</p>';
$_['text_account']  = '帐户';
$_['text_logout']   = '退出';