<?php
// Heading
$_['heading_title']    = '订阅咨询';

// Text
$_['text_account']     = '帐户';
$_['text_newsletter']  = '订阅';
$_['text_success']     = '成功: 已成功更新您的订阅!';

// Entry
$_['entry_newsletter'] = '订阅';
