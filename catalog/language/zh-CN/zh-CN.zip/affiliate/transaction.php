<?php
// Heading
$_['heading_title']      = '您的交易记录';

// Column
$_['column_date_added']  = '加入日期';
$_['column_description'] = '描述';
$_['column_amount']      = '金额 (%s)';

// Text
$_['text_account']       = '帐户';
$_['text_transaction']   = '您的交易记录';
$_['text_balance']       = '您当前的余额是：';
$_['text_empty']         = '您没有任何交易 ！';