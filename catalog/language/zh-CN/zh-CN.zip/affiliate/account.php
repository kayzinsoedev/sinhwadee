<?php
// Heading
$_['heading_title']        = '我的联盟会员帐户';

// Text
$_['text_account']         = '帐户';
$_['text_my_account']      = '我的联盟会员帐户';
$_['text_my_tracking']     = '我的追踪信息';
$_['text_my_transactions'] = '我的交易记录';
$_['text_edit']            = '编辑您的帐户信息';
$_['text_password']        = '更改您的密码';
$_['text_payment']         = '更改您的支付偏好';
$_['text_tracking']        = '自定义的联盟会员追踪代码';
$_['text_transaction']     = '查看您的交易记录';