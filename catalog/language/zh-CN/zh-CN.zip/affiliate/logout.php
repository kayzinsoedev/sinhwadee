<?php
// Heading
$_['heading_title'] = '帐户退出';

// Text
$_['text_message']  = '<p>您的联盟会员帐户已经退出。</p>';
$_['text_account']  = '帐户';
$_['text_logout']   = '退出';