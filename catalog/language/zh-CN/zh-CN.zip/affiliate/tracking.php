<?php
// Heading
$_['heading_title']    = '联盟会员追踪记录';

// Text
$_['text_account']     = '帐户';
$_['text_description'] = '为了确保您能收到我们发送的付款，我们需要记录放置在URL上和我们链接的跟踪代码，您可以使用下面的工具来生成 %s 链接网站。';

// Entry
$_['entry_code']       = '您的追踪代码';
$_['entry_generator']  = '追踪链接生成器';
$_['entry_link']       = '追踪链接';

// Help
$_['help_generator']  = '输入您想要链接到的商品';