<?php
// Text
$_['text_success']           = '您的订单已成功修改';

// Error
$_['error_permission']       = '警告: 您没有权限以访问 API ！';
$_['error_customer']         = '客户详细信息需要设置 ！';
$_['error_payment_address']  = '必须输入付款地址 ！';
$_['error_payment_method']   = '必须输入付款方法 ！';
$_['error_shipping_address'] = '必须输入送货地址 ！';
$_['error_shipping_method']  = '必须输入货运方法 ！';
$_['error_stock']            = '商品标有 * * * 在库存中没有所需的数量 ！';
$_['error_minimum']          = '%s 的最小订单量是 %s ';
$_['error_not_found']        = '警告: 无法找到订单 ！';