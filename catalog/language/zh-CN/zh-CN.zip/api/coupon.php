<?php
// Text
$_['text_success']     = '成功: 已经应用了您的优惠券折扣 ！';

// Error
$_['error_permission'] = '警告: 您没有权限以访问 API ！';
$_['error_coupon']     = '警告: 优惠券要么无效、 过期或达到它的使用极限 ！';