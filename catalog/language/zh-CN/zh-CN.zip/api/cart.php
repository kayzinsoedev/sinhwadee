<?php
// Text
$_['text_success']     = '成功: 您已修改了您的购物车 ！';

// Error
$_['error_permission'] = '警告: 您没有权限以访问 API ！';
$_['error_stock']      = '商品标有 * * * 在库存中没有所需的数量 ！';
$_['error_minimum']    = '%s 的最小订单量是 %s ';
$_['error_store']      = '商品不能从您已经选择的商店购买！';
$_['error_required']   = '必须输入%s ！';