<?php
// Text
$_['text_success'] = '成功:  API session成功启动 ！';

// Error
$_['error_login']  = '警告: 没有匹配的用户名和/或密码。';