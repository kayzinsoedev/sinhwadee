<?php
// Text
$_['text_success']     = '成功: 已经应用了您的奖赏积分折扣 ！';

// Error
$_['error_permission'] = '警告: 您没有权限以访问 API ！';
$_['error_reward']     = '警告: 请输入奖赏积分的使用数量 ！';
$_['error_points']     = '警告: 您没有 %s 的奖赏积分 ！';
$_['error_maximum']    = '警告： 可以应用最大的积分数目为 %s ！';