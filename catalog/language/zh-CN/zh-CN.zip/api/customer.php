<?php
// Text
$_['text_success']       = '您已成功修改客户';

// Error
$_['error_permission']   = '警告: 您没有权限以访问 API ！';
$_['error_firstname']    = '名称必须介于 1 到 32 个字符之间 ！';
$_['error_lastname']     = '姓氏必须介于 1 到 32 个字符之间 ！';
$_['error_email']        = '电子邮件地址无效 ！';
$_['error_telephone']    = '电话必须介于 3 到 32 个字符之间 ！';
$_['error_custom_field'] = '必須輸入%s  ！';