<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = '重量：';
$_['text_insurance']   = '保险高达：';
$_['text_time']        = '预算时间： 48 小时内';