<?php
// Text
$_['text_title']       = '自取
';
$_['text_description'] = '到店自取';