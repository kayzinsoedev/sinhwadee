<?php
// Text
$_['text_title']       = '按件计算运费';
$_['text_description'] = '按件计算运费';