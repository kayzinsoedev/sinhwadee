<?php
// Text
$_['text_title']                 = '英国皇家邮政';
$_['text_weight']                = '重量：';
$_['text_insurance']             = '保险高达：';
$_['text_1st_class_standard']    = 'First Class Standard Post';
$_['text_1st_class_recorded']    = 'First Class Recorded Post';
$_['text_2nd_class_standard']    = 'Second Class Standard Post';
$_['text_2nd_class_recorded']    = 'Second Class Recorded Post';
$_['text_special_delivery_500']  = 'Special Delivery Next Day（500 英镑）';
$_['text_special_delivery_1000'] = 'Special Delivery Next Day (1000 英镑)';
$_['text_special_delivery_2500'] = 'Special Delivery Next Day (2500英镑)';
$_['text_standard_parcels']      = '标准包裹';
$_['text_airmail']               = '航空邮件';
$_['text_international_signed']  = 'International Signed';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Surface';