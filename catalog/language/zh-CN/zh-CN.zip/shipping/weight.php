<?php
// Text
$_['text_title']  = '按重货运';
$_['text_weight'] = '重量：';