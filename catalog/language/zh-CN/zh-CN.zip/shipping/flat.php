<?php
// Text
$_['text_title']       = '定額运费';
$_['text_description'] = '定額运费';