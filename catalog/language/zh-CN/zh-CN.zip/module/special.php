<?php
// Heading
$_['heading_title'] = '特价商品';

// Text
$_['text_tax']      = '不含税:';