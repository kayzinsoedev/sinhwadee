<?php
// Heading
$_['heading_title'] = '信息';

// Text
$_['text_contact']  = '联系我们';
$_['text_sitemap']  = '网站地图';