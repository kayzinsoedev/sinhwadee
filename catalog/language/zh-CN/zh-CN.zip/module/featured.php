<?php
// Heading
$_['heading_title'] = '特色商品';

// Text
$_['text_tax']      = '不含税:';