<?php
// Heading
$_['heading_title'] = '最新商品';

// Text
$_['text_tax']      = '不含税:';