<?php
$_ = array(
    'text_step' => '步骤',
    'diamond_step' => '选择钻石',
    'setting_step' => '选择镶嵌',
    'last_step' => '完成设定',
    'text_change' => '更换',
);