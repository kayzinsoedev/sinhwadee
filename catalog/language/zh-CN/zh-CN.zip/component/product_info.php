<?php
$_ = array(
    'text_more_options_available'   =>  '更多选项',
    'label_enquiry'                 =>  '讯问物品',
    'text_sale' => '促销',
    'text_option' => '选项',
    'text_quantity' => '数量',
    'text_out_of_stock' => '已售完',
);