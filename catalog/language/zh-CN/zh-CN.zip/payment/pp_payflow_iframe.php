<?php
// Text
$_['text_title']				= '信用卡或借记卡';
$_['text_secure_connection']	= '正在创建一个安全的连接...';

// Error
$_['error_connection']			= '无法连接到PayPal。请联系商店的管理员寻求帮助或选择另外一个不同的支付方式。';