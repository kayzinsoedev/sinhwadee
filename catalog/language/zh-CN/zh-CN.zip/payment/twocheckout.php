<?php
// Text
$_['text_title'] = '信用卡 / 借记卡 (2Checkout)';