<?php
// Text
$_['text_title']				= '信用卡 / 借记卡 (SagePay)';
$_['text_credit_card']			= '信用卡详细信息';

// Entry
$_['entry_cc_owner']			= '持卡人';
$_['entry_cc_number']			= '卡号';
$_['entry_cc_expire_date']		= '信用卡到期日期';
$_['entry_cc_cvv2']				= '信用卡安全代码 （CVV2)';