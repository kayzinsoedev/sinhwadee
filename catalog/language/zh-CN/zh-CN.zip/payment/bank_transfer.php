<?php
// Text
$_['text_title']				= '银行转帐';
$_['text_instruction']			= '银行转账说明';
$_['text_description']			= '请转帐总金额到以下的银行帐户。';
$_['text_payment']				= '您的订单将不会发货直到我们收到您的付款。';