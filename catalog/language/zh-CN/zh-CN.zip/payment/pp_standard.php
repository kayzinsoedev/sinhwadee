<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= '警告: 支付网关现正在 \' 测试模式 (Sandbox Mode)\'。您的帐户将不会被收取费用。';
$_['text_total']	= '货运，手续费，折扣和税费';