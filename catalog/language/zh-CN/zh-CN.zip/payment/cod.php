<?php
// Text
$_['text_title'] = '货到付款';