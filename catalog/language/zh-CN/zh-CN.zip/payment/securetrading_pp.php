<?php

$_['text_title'] = '信用卡 / 借记卡';
$_['button_confirm'] = '确认';

$_['text_postcode_check'] = '邮政编码查询： %s';
$_['text_security_code_check'] = 'CVV2 查询： %s';
$_['text_address_check'] = '地址查询： %s';
$_['text_not_given'] = '不给';
$_['text_not_checked'] = '不检查';
$_['text_match'] = '相配';
$_['text_not_match'] = '不相配';
$_['text_payment_details'] = '付款的详细信息';

$_['entry_card_type'] = '信用卡类型';