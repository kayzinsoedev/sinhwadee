<?php
// Text
$_['text_title']				= '支票 / 汇票';
$_['text_instruction']			= '支票 / 汇票订单说明';
$_['text_payable']				= '请付给：';
$_['text_address']				= '发送到:';
$_['text_payment']				= '您的订单将不会发货直到我们收到您的付款。';