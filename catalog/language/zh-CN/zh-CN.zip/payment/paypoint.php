<?php
// Heading
$_['heading_title']				= '感谢您与 %s 购物......';

// Text
$_['text_title']				= '信用卡 / 借记卡 (PayPoint)';
$_['text_response']				= 'PayPoint 的回应：';
$_['text_success']				= '......成功地收到您的付款。';
$_['text_success_wait']			= '<b><span style="color: #FF0000"> 请稍候...</span></b>您的订单处理完成。<br>如果十秒钟内没有指示您自动更新，请点击 <a href="%s"> 这里</a>。';
$_['text_failure']				= '...您的付款已被取消了 ！';
$_['text_failure_wait']			= '<b><span style="color: #FF0000"> 请稍候...</span></b><br>如果十秒钟内没有自动重新定向，请点击 <a href="%s"> 这里</a>。';