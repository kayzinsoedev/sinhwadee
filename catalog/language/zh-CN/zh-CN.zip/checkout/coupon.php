<?php
// Heading
$_['heading_title'] = '使用优惠券代码';

// Text
$_['text_success']  = '成功: 您的优惠券折扣已经应用 ！';

// Entry
$_['entry_coupon']  = '请在这里输入您的优惠券代码';

// Error
$_['error_coupon']  = '警告: 优惠券要么无效、 过期或已达到其使用极限 ！';
$_['error_empty']   = '警告: 请输入优惠券代码 ！';