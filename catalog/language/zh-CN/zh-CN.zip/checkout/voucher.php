<?php
// Heading
$_['heading_title'] = '使用礼品券';

// Text
$_['text_success']  = '成功: 您的礼品券折扣已经应用 ！';

// Entry
$_['entry_voucher'] = '输入您的礼品券代码';

// Error
$_['error_voucher'] = '警告: 礼品券要么无效或余额已经用完了 ！';
$_['error_empty']   = '警告: 请输入礼品券代码 ！';