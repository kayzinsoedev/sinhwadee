<?php
// Heading
$_['heading_title'] = '付款失败 ！';

// Text
$_['text_basket']   = '购物车';
$_['text_checkout'] = '结帐';
$_['text_failure']  = '付款失败';
$_['text_message']  = '<p>处理您的付款时出现了一个问题因此订单没有完成。</p><p>可能的原因是：</p><ul><li>资金不足</li> <li>验证失败</li></ul><p>请尝试使用另一种的付款方式再次订购。</p><p>如果问题仍然存在，请 <a href="%s"> 联系我们</a> 并提供订单的详细资料。</p>';
