<?php
// Heading
$_['heading_title'] = '使用奖赏积分 (可用的 %s)';

// Text
$_['text_success']  = '成功: 您的奖赏积分折扣已经应用 ！';

// Entry
$_['entry_reward']  = '使用积分 (最多 %s)';

// Error
$_['error_reward']  = '警告: 请输入奖赏积分的使用数量 ！';
$_['error_points']  = '警告: 您没有 %s 的奖赏积分 ！';
$_['error_maximum'] = '警告： 可以应用的最大积分数目为 %s ！';