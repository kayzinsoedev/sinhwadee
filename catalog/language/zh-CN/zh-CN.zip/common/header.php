<?php
// Text
$_['text_home']          = '首页';
$_['text_wishlist']      = '收藏清单 (%s)';
$_['text_shopping_cart'] = '购物车';
$_['text_category']      = '类别';
$_['text_account']       = '我的账户';
$_['text_register']      = '注册';
$_['text_login']         = '登录';
$_['text_order']         = '订单记录';
$_['text_transaction']   = '交易记录';
$_['text_download']      = '下载附件';
$_['text_logout']        = '退出';
$_['text_checkout']      = '结帐';
$_['text_search']        = '搜索';
$_['text_all']           = '查看所有';