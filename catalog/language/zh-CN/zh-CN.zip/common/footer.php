<?php
// Text
$_['text_information']  = '信息';
$_['text_service']      = '客户服务';
$_['text_extra']        = '其他';
$_['text_contact']      = '联系我们';
$_['text_return']       = '商品退货';
$_['text_sitemap']      = '网站地图';
$_['text_manufacturer'] = '品牌';
$_['text_voucher']      = '礼品券';
$_['text_affiliate']    = '联盟会员';
$_['text_special']      = '特价商品';
$_['text_account']      = '我的账户';
$_['text_order']        = '订单记录';
$_['text_wishlist']     = '收藏清单';
$_['text_newsletter']   = '订阅咨询';
$_['text_powered']      = '<a href="http://www.opencart.cn"></a>  %s © %s ';