<?php
// Text
$_['text_items']    = '项目 %s-%s';
$_['text_empty']    = '您的购物车是空的 ！';
$_['text_cart']     = '查看购物车';
$_['text_checkout'] = '结帐';
$_['text_quantity'] = '数量';
$_['text_total']    = '合计';
$_['text_price']    = '价格';
$_['text_recurring']  = '支付配置';